import React, { Component } from 'react';

export default class DelHost extends Component{
    constructor(props){
        super(props);
        this.state = {}
    }

    render(){
        return(
            <p>删除域名</p>
        )
    }
}